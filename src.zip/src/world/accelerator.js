/**
 * Physical accelerator (Arduino + potentiometer/pedal) via the Web Serial API.
 *
 * Arduino sketch (pot: outer pins to 5V and GND, middle pin to A0):
 *
 *   void setup() { Serial.begin(115200); }
 *   void loop()  { Serial.println(analogRead(A0)); delay(16); }
 *
 * Works in Chrome / Edge on https or localhost. connect() must be called
 * from a user click (the "Connect accelerator" button).
 */
export class Accelerator {
    constructor(onThrottle) {
        this.onThrottle = onThrottle;
        this.min = 0;       // raw value with the pedal released
        this.max = 1023;    // raw value with the pedal fully pressed (10-bit ADC)
        this.deadZone = 0.03;
        this.smoothing = 0.4;
        this.value = 0;
        this.port = null;
        this.reader = null;
    }

    static get supported() {
        return 'serial' in navigator;
    }

    async connect(baudRate = 115200) {
        this.port = await navigator.serial.requestPort();
        await this.port.open({ baudRate });

        const decoder = new TextDecoderStream();
        this.port.readable.pipeTo(decoder.writable);
        this.reader = decoder.readable.getReader();
        this.readLoop();
    }

    async disconnect() {
        try {
            if (this.reader) await this.reader.cancel();
            if (this.port) await this.port.close();
        } catch (e) {
            console.error(e);
        }
        this.reader = null;
        this.port = null;
        this.onThrottle(0);
    }

    async readLoop() {
        let buffer = '';
        try {
            while (true) {
                const { value, done } = await this.reader.read();
                if (done) break;
                buffer += value;
                const lines = buffer.split('\n');
                buffer = lines.pop();
                for (const line of lines) {
                    const raw = parseInt(line.trim(), 10);
                    if (!Number.isNaN(raw)) this.handle(raw);
                }
            }
        } catch (e) {
            console.error('Accelerator read error:', e);
        }
        this.onThrottle(0);   // cable pulled out: stop accelerating
    }

    handle(raw) {
        let t = (raw - this.min) / (this.max - this.min);
        t = Math.min(Math.max(t, 0), 1);
        if (t < this.deadZone) t = 0;
        this.value += (t - this.value) * this.smoothing;
        this.onThrottle(this.value);
    }
}
