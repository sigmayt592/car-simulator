import './style.css'
import * as THREE from 'three'
import { Reflector } from 'three/examples/jsm/objects/Reflector.js';
import * as CANNON from 'cannon-es'
import cannonDebugger from 'cannon-es-debugger'
import Guify from 'guify'
import Stats from 'stats.js';
import {Car} from './world/car';
import {Accelerator} from './world/accelerator';

const loader = document.querySelector('.loader');

var stats = new Stats();
stats.showPanel( 0 ); // 0: fps, 1: ms, 2: mb, 3+: custom
document.body.appendChild( stats.dom );

/**
 * Base
 */
// Canvas
const gui = new Guify({align: 'right', theme: 'dark', width: '400px', barMode: 'none'})
gui.Register({type: 'folder', label: 'Upload', open: true})
gui.Register({type: 'folder', label: 'Vehicle', open: true})
gui.Register({type: 'folder', label: 'Chassis', open: true})
gui.Register({type: 'folder', label: 'Wheels', open: true})
gui.Register({type: 'folder', label: 'Generate Code', open: true})

gui.Register({folder: 'Chassis', type: 'folder', label: 'Chassis Helper', open: true})
gui.Register({folder: 'Chassis', type: 'folder', label: 'Chassis Model', open: true})
gui.Register({folder: 'Chassis Helper', type: 'folder', label: 'Chassis Helper Dimension', open: true})
gui.Register({folder: 'Chassis Model', type: 'folder', label: 'Chassis Model Position', open: true})
gui.Register({folder: 'Wheels', type: 'folder', label: 'Wheels Helper', open: true})
gui.Register({folder: 'Wheels Helper', type: 'folder', label: 'Wheel Helper Position', open: false})

const loadingManager = new THREE.LoadingManager();
const canvas = document.querySelector('canvas.webgl')
const scene = new THREE.Scene()
const world = new CANNON.World({
    gravity: new CANNON.Vec3(0, -9.82, 0), // m/s²
})
world.broadphase = new CANNON.SAPBroadphase(world);
// cannonDebugger(scene, world.bodies, {color: 0x00ff00})

const car = new Car(scene, world, gui, loadingManager);

// Physical accelerator (Arduino over Web Serial)
const accelerator = new Accelerator((v) => car.setThrottle(v));
document.querySelector('.connect-accelerator').addEventListener('click', () => {
    if(!Accelerator.supported) return alert('Web Serial is only available in Chrome or Edge');
    accelerator.connect().catch(console.error);
});
loadingManager.onProgress = (url, itemsLoaded, itemsTotal) => {
    loader.textContent = `${Math.round(itemsLoaded / itemsTotal * 100)}% Loading...`;
    if(itemsLoaded === itemsTotal) {
      setTimeout(() => {
        loader.style.opacity = '0';
      }, 2000);
    }
}
loadingManager.onLoad = () => {
    car.init();
}

const bodyMaterial = new CANNON.Material();
const groundMaterial = new CANNON.Material();
const bodyGroundContactMaterial = new CANNON.ContactMaterial(
    bodyMaterial,
    groundMaterial,
    {
        friction: 0.1,
        restitution: 0.3
    }
)
world.addContactMaterial(bodyGroundContactMaterial)

/**
 * Lights
 */
const ambientLight = new THREE.AmbientLight(0xffffff, 0.4)
const spotLight = new THREE.SpotLight( 0x29dfff, 2, 0, 0.9, 1, 0 );
spotLight.position.set( 7, 1.291, -6 );
const spotLight2 = new THREE.SpotLight( 0x943dff, 2, 0, 0.9, 1, 0 );
spotLight2.position.set( -7, 1.291, -6 );
const spotLight3 = new THREE.SpotLight( 0xd5f8ff, 2, 0, 0.9, 1, 0 );
spotLight3.position.set( 0, 1.291, 7 );
scene.add(spotLight, spotLight2, spotLight3);

/**
 * Cube Texture Loader
 */
const cubeTextureLoader = new THREE.CubeTextureLoader()
const cubeEnvironmentMapTexture = cubeTextureLoader.load([
    "/textures/environmentMaps/2/px.jpg",
    "/textures/environmentMaps/2/nx.jpg",
    "/textures/environmentMaps/2/py.jpg",
    "/textures/environmentMaps/2/ny.jpg",
    "/textures/environmentMaps/2/pz.jpg",
    "/textures/environmentMaps/2/nz.jpg",
])
// scene.background = cubeEnvironmentMapTexture
scene.environment = cubeEnvironmentMapTexture

/**
 * Sizes
 */
const sizes = {
    width: window.innerWidth,
    height: window.innerHeight
}

window.addEventListener('resize', () =>
{
    // Update sizes
    sizes.width = window.innerWidth
    sizes.height = window.innerHeight

    // Update camera
    camera.aspect = sizes.width / sizes.height
    camera.updateProjectionMatrix()

    // Update renderer
    renderer.setSize(sizes.width, sizes.height)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
})

/**
 * Floor
 */
const floorGeo = new THREE.PlaneBufferGeometry(100, 100);
const floorMirror = new Reflector( floorGeo, {
    clipBias: 0.003,
    textureWidth: window.innerWidth * window.devicePixelRatio,
    textureHeight: window.innerHeight * window.devicePixelRatio,
    color: 0xffffff
});
const floorMesh = new THREE.Mesh(
    floorGeo,
    new THREE.MeshStandardMaterial({
        color: 0xffffff,
        roughness: 0.5,
        metalness: 0,
        emissive: 0xffffff,
        emissiveIntensity: -0.36,
        transparent: true,
        opacity: 0.7
    })
)
floorMirror.rotation.x = -Math.PI * 0.5;
floorMesh.rotation.x = -Math.PI * 0.5;
floorMesh.position.y = 0.001;
scene.add(floorMirror, floorMesh)

/**
 * Road (3 lanes, dashed lane lines, solid edge lines)
 */
const ROAD_WIDTH = 12
const ROAD_LENGTH = 2000
const roadCanvas = document.createElement('canvas')
roadCanvas.width = roadCanvas.height = 256
const rc = roadCanvas.getContext('2d')
rc.fillStyle = '#2b2b2b'; rc.fillRect(0, 0, 256, 256)
rc.fillStyle = '#ffffff'
rc.fillRect(6, 0, 6, 256)        // left edge line
rc.fillRect(244, 0, 6, 256)      // right edge line
rc.fillRect(83, 0, 5, 128)       // dashed lane line 1
rc.fillRect(168, 0, 5, 128)      // dashed lane line 2

const roadTexture = new THREE.CanvasTexture(roadCanvas)
roadTexture.wrapS = roadTexture.wrapT = THREE.RepeatWrapping
roadTexture.repeat.set(1, ROAD_LENGTH / ROAD_WIDTH)
roadTexture.anisotropy = 8

const road = new THREE.Mesh(
    new THREE.PlaneBufferGeometry(ROAD_WIDTH, ROAD_LENGTH),
    new THREE.MeshStandardMaterial({ map: roadTexture, roughness: 0.9 })
)
road.rotation.x = -Math.PI * 0.5
road.position.y = 0.01
scene.add(road)
scene.add(new THREE.HemisphereLight(0xffffff, 0x444444, 0.8))   // spotlights only cover the start area

const floorS = new CANNON.Plane();
const floorB = new CANNON.Body();
floorB.mass = 0;

floorB.addShape(floorS);
world.addBody(floorB);

floorB.quaternion.setFromAxisAngle(
    new CANNON.Vec3(-1, 0, 0),
    Math.PI * 0.5
);

/**
 * Camera: fixed third-person, behind the car
 */
const camera = new THREE.PerspectiveCamera(60, sizes.width / sizes.height, 0.1, 500)
const CAMERA_OFFSET = new THREE.Vector3(0, 3, -9)    // height 3, distance 9 behind the car
const CAMERA_LOOK_AHEAD = 6                          // look 6 m in front of the car
const cameraTarget = new THREE.Vector3()
camera.position.copy(CAMERA_OFFSET)
scene.add(camera)

/**
 * Renderer
 */
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true })
renderer.setSize(sizes.width, sizes.height)
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))

/**
 * Animate: capped at 60 FPS, fixed physics step
 */
const TARGET_FPS = 60
const frameInterval = 1000 / TARGET_FPS
const timeStep = 1 / TARGET_FPS
let lastFrameTime = 0
let lastCallTime

const tick = (now = 0) =>
{
    window.requestAnimationFrame(tick)

    const elapsed = now - lastFrameTime
    if (elapsed < frameInterval - 1) return          // too early: skip this frame
    lastFrameTime = now - (elapsed % frameInterval)

    stats.begin()

    // Physics: fixed 1/60 s step
    const time = performance.now() / 1000 // seconds
    if (!lastCallTime) {
        world.step(timeStep)
    } else {
        world.step(timeStep, time - lastCallTime)
    }
    lastCallTime = time

    // Camera follows the car along Z only, smoothed
    if (car.car && car.car.chassisBody) {
        const z = car.car.chassisBody.position.z
        cameraTarget.set(CAMERA_OFFSET.x, CAMERA_OFFSET.y, z + CAMERA_OFFSET.z)
        camera.position.lerp(cameraTarget, 0.2)
        camera.lookAt(0, 1, z + CAMERA_LOOK_AHEAD)

        // Keep the 100x100 floor under the car
        floorMirror.position.z = floorMesh.position.z = z
    }

    // Render
    renderer.render(scene, camera)
    stats.end()
}

tick()
